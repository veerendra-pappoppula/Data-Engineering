# Project: Data Modeling with Postgres

A startup, Sparkify, has a collection of their songs and user activity data in json files. The aim of this project is to help Sparkify have easy access to their data in a relational database and give them the ability to perform analytical queries on their song data to improve customer experience

## Getting Started

5 tables are being created in a postgresql database. 
Songplays: Fact Table containing all the songs being played by a user and their relative session and song information.
Songs: Dimension Table containing song information
Artists: Dimension Table containing artist information
Users: Dimension Table containing user information
Time: Dimension Table containing session time information

Data files are in json format separated as Song and Log Data. Song data contains information about Songs and Artists.
Log data contains information about User, Time and Songplays

We are going to use python and its psycopg2, pandas, sql_queries, os and glob modules to achieve the requirements.Different python files are created accordingly.

sql_queries.py : Contains DDL & DML statements for the above mentioned 5 tables.
create_tables.py: Executes the statements in sql_queries.py
etl.ipynb: Helps to break down the whole etl process into a step by step process.
test.ipynb: Helps to validate the tables and data that is created.
etl.py: Loads information from the json files to the tables.
final_load.ipynb: Contains steps to execute the project.

### Executing project

Run create_tables.py script using %run create_tables.py. This will drop tables if any exist already and (re)-create the tables as necessary.
Run the etl.py which will read the filenames from the data directories, use them to load the tables created above.
Both the above steps are in final_load.ipynb

#### Analytical queries

The below query gives you the names and their membership level of the top 5 users based on the total number of songs they have listened to.

%load_ext sql  #loading sql extension

%sql postgresql://student:student@127.0.0.1/sparkifydb  #connect to the database

%sql select first_name,last_name,level, count(*) from songplays s join users u on s.user_id=u.user_id  group by first_name,last_name,level order by count(*) desc LIMIT 5;

## Acknowledgments

* SLACK project group

