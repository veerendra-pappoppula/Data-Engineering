# DROP TABLES

songplay_table_drop = "drop table if exists songplays;"
user_table_drop = "drop table if exists users;"
song_table_drop = "drop table if exists songs;"
artist_table_drop = "drop table if exists artists;"
time_table_drop = "drop table if exists time;"

# CREATE TABLES

songplay_table_create = ("""create table if not exists songplays (songplay_id serial primary key
                                                              ,start_time timestamp
                                                              ,user_id varchar not null
                                                              ,level varchar not null
                                                              ,song_id varchar
                                                              ,artist_id varchar
                                                              ,session_id varchar not null
                                                              ,location varchar
                                                              ,user_agent varchar);
""")


user_table_create = ("""create table if not exists users (user_id varchar primary key
                                                          ,first_name varchar
                                                          ,last_name varchar
                                                          ,user_gender varchar
                                                          ,user_level varchar);
""")

song_table_create = ("""create table if not exists songs (song_id varchar primary key
                                                          ,song_title varchar
                                                          ,artist_id varchar
                                                          ,year int
                                                          ,duration numeric);
""")

artist_table_create = ("""create table if not exists artists (artist_id varchar primary key
                                                            ,artist_name varchar
                                                            ,artist_location varchar
                                                            ,latitude numeric
                                                            ,longitude numeric);
""")

time_table_create = ("""create table if not exists time (start_time timestamp primary key
                                                         ,hour int
                                                         ,day int
                                                         ,week int
                                                         ,month int
                                                         ,year int
                                                         ,weekday int);
""")

# INSERT RECORDS

songplay_table_insert = ("""insert into songplays (start_time
                                                   ,user_id
                                                   ,level
                                                   ,song_id
                                                   ,artist_id
                                                   ,session_id
                                                   ,location
                                                   ,user_agent) values (to_timestamp(%s/1000),%s,%s,%s,%s,%s,%s,%s)
                                                   ;
""")

user_table_insert = ("""insert into users (user_id 
                                           ,first_name
                                           ,last_name
                                           ,user_gender
                                           ,user_level) values (%s,%s,%s,%s,%s)
                                           on conflict (user_id)
                                           do update set user_level = EXCLUDED.user_level ;
""")

song_table_insert = ("""insert into songs (song_id   
                                           ,song_title 
                                           ,artist_id 
                                           ,year 
                                           ,duration) values (%s,%s,%s,%s,%s)
                                           on conflict (song_id)
                                           do nothing;
""")

artist_table_insert = ("""insert into artists (artist_id
                                               ,artist_name
                                               ,artist_location
                                               ,latitude
                                               ,longitude) values (%s,%s,%s,%s,%s)
                                               on conflict (artist_id)
                                               do nothing;
""")


time_table_insert = ("""insert into time (start_time 
                                          ,hour 
                                          ,day 
                                          ,week 
                                          ,month 
                                          ,year 
                                          ,weekday ) values (%s,%s,%s,%s,%s,%s,%s)
                                          on conflict (start_time)
                                          do nothing;
""")

# FIND SONGS

song_select = ("""select s.song_id, a.artist_id
                        from songs s
                        join artists a
                        on s.artist_id=a.artist_id
                        where song_title = %s AND artist_name = %s AND duration = %s
                        
""")

# QUERY LISTS

create_table_queries = [songplay_table_create, user_table_create, song_table_create, artist_table_create, time_table_create]
drop_table_queries = [songplay_table_drop, user_table_drop, song_table_drop, artist_table_drop, time_table_drop]