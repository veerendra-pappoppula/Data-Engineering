# Project: Create a ETL pipeline using Spark and AWS S3

A startup, Sparkify, has a collection of their songs and user activity data in json files in AWS S3. The aim of this project is to help Sparkify have easy access to their data in a data lake, also created in S3 and give them the ability to perform analytical queries on their song data to improve customer experience

## Getting Started

5 tables are being created in the data lake. 
Songplays: Table containing all the songs being played by a user and their relative session and song information.
Songs: Table containing song information
Artists: Table containing artist information
Users: Table containing user information
Time: Table containing session time information

Data files are in json format separated as Song and Log Data. Song data contains information about Songs and Artists.
Log data contains information about User, Time and Songplays

We are going to use python and its pyspark, pyspark.sql, os modules to achieve the requirements.

dl.cfg: contains the aws access key and security key. do not use quotes while entering information in this file.
final_etl.py: Loads information from the directory of json files to the tables and creates parquets which stores information in a columnar format.
final_load.ipynb: Contains steps to execute the project.
test-etl.ipynb: contains step by process to test etl pipeline with local and s3 data.
data: folder contains subset of data files locally for testing purposes which have been unzipped for use. It also contains the parquet files that were written as part of testing.
etl-py: is the empty etl guideline file that helps you finish the project.


### Executing project

Run final_etl.py script using %run final_etl.py. This will read the filenames from the data directories, use them to load the parquets.
The above step is in final_load.ipynb


## Acknowledgments

* SLACK project group
* https://spark.apache.org/docs/latest/sql-data-sources-parquet.html

