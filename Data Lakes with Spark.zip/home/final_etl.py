import configparser
from datetime import datetime
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, monotonically_increasing_id
from pyspark.sql.functions import year, month, dayofmonth, hour, weekofyear, date_format


config = configparser.ConfigParser()
config.read_file(open('dl.cfg'))

os.environ['AWS_ACCESS_KEY_ID']=config['AWS']['AWS_ACCESS_KEY_ID']
os.environ['AWS_SECRET_ACCESS_KEY']=config['AWS']['AWS_SECRET_ACCESS_KEY']


def create_spark_session():
    """
    Description: This function can be used to create a spark session

    Arguments:
        configuration parameters

    Returns:
        Spark session variable
    """
    spark = SparkSession \
        .builder \
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:2.7.0") \
        .getOrCreate()
    return spark


def process_song_data(spark, input_data, output_data):
    """
    Description: This function can be used to read the song files from the input data folder location and create the necessary columnar parquet              files as required.

    Arguments:
        Spark session variable
        input data: folder location
        output data: folder location for output

    Returns:
        None
    """
    # get filepath to song data file
    song_data = os.path.join(input_data,"song_data/*/*/*/*")
    
    # read song data file
    df = spark.read.json(song_data)

    # extract columns to create songs table
    songs_table = df.select("song_id","title","artist_id","year","duration")
    
    # write songs table to parquet files partitioned by year and artist
    songs_table.write.partitionBy("year","artist_id").parquet(os.path.join(output_data,"songs"), 'overwrite')

    # extract columns to create artists table
    artists_table = df.select("artist_id","artist_name","artist_location","artist_latitude","artist_longitude")
    
    # write artists table to parquet files
    artists_table.write.parquet(os.path.join(output_data,"artists"), 'overwrite')


def process_log_data(spark, input_data, output_data):
    """
    Description: This function can be used to read the log files from the input data folder location and create the necessary columnar parquet               files as required.It transforms the epoch timestamp using the udf function to create a timestamp variable that is further split into hour, day,           week, month and year.

    Arguments:
        Spark session variable
        input data: folder location
        output data: folder location for output

    Returns:
        None
    """
    # get filepath to log data file
    log_data = os.path.join(input_data,"log_data/*/*/*")

    # read log data file
    df = spark.read.json(log_data)
    
    # filter by actions for song plays
    df = df.where(df.page=="NextSong")

    # extract columns for users table    
    users_table = df.select("userid","firstname","lastname","gender","level")
    
    # write users table to parquet files
    users_table.write.parquet(os.path.join(output_data,"users"), 'overwrite')

    # create timestamp column from original timestamp column
    get_timestamp = udf(lambda x: datetime.fromtimestamp(x/1000.0).strftime('%Y-%m-%d %H:%M:%S'))
    df = df.withColumn('start_time',get_timestamp(df['ts']))
    
    # create datetime column from original timestamp column
    # get_datetime = udf()
     
    
    # extract columns to create time table
    time_table = df.select(df['start_time'], hour(df['start_time']).alias('hour'), dayofmonth(df['start_time']).alias('day'),                                                   weekofyear(df['start_time']).alias('week'), month(df['start_time']).alias('month'),year(df['start_time']).alias('year') )
    
    # write time table to parquet files partitioned by year and month
    time_table.write.partitionBy("year","month").parquet(os.path.join(output_data,"time"), 'overwrite')

    # read in song data to use for songplays table
    song_df = spark.read.parquet(os.path.join(output_data,"songs"))
    
    # create temporary views of data frames to use spark.sql
    df.createOrReplaceTempView("new_df_table")
    song_df.createOrReplaceTempView("song_df_table")

    # extract columns from joined song and log datasets to create songplays table 
    songplays_table = spark.sql('''select monotonically_increasing_id() as songplay_id, start_time
                                   , userId as user_id,level, song_id, artist_id, sessionid as session_id, location,userAgent as user_agent
                                   , month(start_time) as month, year(start_time) as year
                                   from new_df_table a join song_df_table b on lower(a.song)=lower(b.title)  ''')

    # write songplays table to parquet files partitioned by year and month
    songplays_table.write.partitionBy("year","month").parquet(os.path.join(output_data,"songplays"), 'overwrite')


def main():
    spark = create_spark_session()
    input_data = "s3a://udacity-dend/"
    output_data = "s3a://aws-emr-resources-714348276754-us-east-1/"
    
    process_song_data(spark, input_data, output_data)    
    process_log_data(spark, input_data, output_data)


if __name__ == "__main__":
    main()
