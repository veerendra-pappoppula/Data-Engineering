# Import Python packages 
import pandas as pd
import cassandra
import re
import os
import glob
import numpy as np
import json
import csv

# get file location
filepath = os.getcwd() + '/event_data'

for root, dirs, files in os.walk(filepath):
    file_path_list = glob.glob(os.path.join(root,'*'))

# read information from file
full_data_rows_list = [] 
 
for f in file_path_list:
    with open(f, 'r', encoding = 'utf8', newline='') as csvfile: 
        csvreader = csv.reader(csvfile) 
        next(csvreader)
        for line in csvreader:
            #print(line)
            full_data_rows_list.append(line) 

csv.register_dialect('myDialect', quoting=csv.QUOTE_ALL, skipinitialspace=True)

# create a single file

with open('event_datafile_new.csv', 'w', encoding = 'utf8', newline='') as f:
    writer = csv.writer(f, dialect='myDialect')
    writer.writerow(['artist','firstName','gender','itemInSession','lastName','length',\
                'level','location','sessionId','song','userId'])
    for row in full_data_rows_list:
        if (row[0] == ''):
            continue
        writer.writerow((row[0], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[12], row[13], row[16]))

# check the number of rows in your csv file
print('number of rows in your csv file:')
with open('event_datafile_new.csv', 'r', encoding = 'utf8') as f:
    print(sum(1 for line in f))
	
# This should make a connection to a Cassandra instance your local machine 
# (127.0.0.1)

from cassandra.cluster import Cluster
cluster = Cluster(['127.0.0.1'])
session = cluster.connect()

try:
    session.execute("""
    CREATE KEYSPACE IF NOT EXISTS project2 
    WITH REPLICATION = 
    { 'class' : 'SimpleStrategy', 'replication_factor' : 1 }"""
)
except Exception as e:
    print(e)


try:
    session.set_keyspace('project2')
except Exception as e:
    print(e)

## Query 1:  Give me the artist, song title and song's length in the music app history that was heard during \
## sessionId = 338, and itemInSession = 4

session.execute("DROP TABLE IF EXISTS event_data_session")

query = "CREATE TABLE IF NOT EXISTS event_data_session "
query = query + "(session_id int, iteminsession int,artist text, song text, length float, \
                PRIMARY KEY (session_id, iteminsession))"
try:
    session.execute(query)
except Exception as e:
    print(e)

file = 'event_datafile_new.csv'

# insert event_data_session
with open(file, encoding = 'utf8') as f:
    csvreader = csv.reader(f)
    next(csvreader) # skip header
    for line in csvreader:
        query = "INSERT INTO event_data_session (session_id, iteminsession, artist, song, length )"
        query = query + "VALUES (%s, %s, %s, %s, %s)"
        session.execute(query, (int(line[8]), int(line[3]), line[0], line[9], float(line[5])))
		
query = "select artist, song, length from event_data_session WHERE session_id=338 and iteminsession=4"
try:
    rows = session.execute(query)
except Exception as e:
    print(e)

print ('\nItem 4 in session_id 338 is: ')

print ('artist','|','song','|','length')
    
for row in rows:
    print (row.artist,'|', row.song,'|', row.length)

## Query 2: Give me only the following: name of artist, song (sorted by itemInSession) and user (first and last name)\
## for userid = 10, sessionid = 182

session.execute("DROP TABLE IF EXISTS event_data_user")

query = "CREATE TABLE IF NOT EXISTS event_data_user "
query = query + "(user_id int, session_id int, iteminsession int,user_first_name text, user_last_name text, artist text, song text, \
                PRIMARY KEY (user_id, session_id, iteminsession))"
try:
    session.execute(query)
except Exception as e:
    print(e)

file = 'event_datafile_new.csv'

with open(file, encoding = 'utf8') as f:
    csvreader = csv.reader(f)
    next(csvreader) # skip header
    for line in csvreader:
        query = "INSERT INTO event_data_user (user_id, session_id, iteminsession,user_first_name, user_last_name,  artist, song )"
        query = query + "VALUES (%s, %s, %s, %s, %s, %s, %s)"
        session.execute(query, (int(line[10]), int(line[8]), int(line[3]), line[1], line[4], line[0], line[9]))

query = "select artist, song, user_first_name, user_last_name, iteminsession from event_data_user WHERE user_id=10 and session_id=182"
try:
    rows = session.execute(query)
except Exception as e:
    print(e)

print ('\n\nAlbums listened to by userid 10 in sessionid 182: ')

print ('artist','|','song','|','user_first_name','|','user_last_name')
    
for row in rows:
    print (row.artist,'|', row.song,'|', row.user_first_name,'|', row.user_last_name)
	
## Query 3: Give me every user name (first and last) in my music app history who listened to the song 'All Hands Against His Own'

session.execute("DROP TABLE IF EXISTS event_data_song")

query = "CREATE TABLE IF NOT EXISTS event_data_song "
query = query + "(song text,user_id int, user_first_name text, user_last_name text,  \
                PRIMARY KEY (song,user_id))"
try:
    session.execute(query)
except Exception as e:
    print(e)

file = 'event_datafile_new.csv'

with open(file, encoding = 'utf8') as f:
    csvreader = csv.reader(f)
    next(csvreader) # skip header
    for line in csvreader:
        query = "INSERT INTO event_data_song (song,user_id, user_first_name, user_last_name)"
        query = query + "VALUES (%s, %s, %s, %s)"
        session.execute(query, (line[9],int(line[10]), line[1], line[4]))

query = "select user_first_name, user_last_name, song from event_data_song WHERE song='All Hands Against His Own'"
try:
    rows = session.execute(query)
except Exception as e:
    print(e)

print ('\n\nUsers who listened to the song "All Hands Against His Own": ')

print ('user_first_name','|','user_last_name')
    
for row in rows:
    print (  row.user_first_name,'|', row.user_last_name)

# Drop Tables	

session.execute("DROP TABLE IF EXISTS event_data_session")

session.execute("DROP TABLE IF EXISTS event_data_user")

session.execute("DROP TABLE IF EXISTS event_data_song")