# Project: Data Modeling with Apache Cassandra

A startup, Sparkify, has a collection of their songs and user activity data in csv files. The aim of this project is to help Sparkify model their tables in order to query their data effectively 

## Getting Started

3 tables are being created in a apache cassandra database based on the queries that need to be performed. 
event_data_session : To find information about a specific song in a particular session
event_data_user: To find the list of songs a user has listened to in a particular session
event_data_song: To find the user list who have listened to a particular song

Data files are in csv format which are combined into a single csv file called event_datafile_new.csv

We are going to use python and its various modules to achieve the requirements.

Project_1B.py: loads the information from csv files into the above tables and executes the queries to give the results. 
Execute_Script.ipynb: Contains steps to execute the project.

### Building data models

Query 1: To find the artist, song title and song's length in the music app history that was heard during sessionId = 338, and itemInSession = 4

One of the main criterias in NoSQL database is that you cannot query the whole table. Keeping that in mind and according to the requirements, we only need  the artist, song title, song length , sessionId and itemInSession from the event data csv file. The sessionId becomes the partition key and itemInSession becomes the clustering column. Together they become the primary key. Also, by looking at the data we are querying, there should be only one song per session per itemInSession. 

Query 2: To find name of artist, song (sorted by itemInSession) and user (first and last name) for userid = 10, sessionid = 182

A user can have multiple sessions in their whole life time, but the user can only have one live session, or in other words the userid and sessionid together make a primary key. In order for the sort to exist, we also need to itemInSession to the clustering column list.

Query 3: To find the users name's (first and last) in my music app history who listened to the song 'All Hands Against His Own'

As we are going to look for users by song, song title becomes a partition key, but there will be many users who have listened to the same song. Considering this, we can add the userid to the clustering column to make it a primary key. If we do not add userid then we will get the user who last listened to the song being queried for, until the query is executed. Whenever a new user listens to the same song, the previous data will be overwritten.

#### Executing project

Run Project_1B.py script using %run Project_1B.py.
Alternatively, you can execute the command in Execute_Script.ipynb

## Acknowledgments

* SLACK project group